# University Management System — Project Report

**Course:** Object-Oriented Programming  
**Language:** Java 17  
**Team members:** Alexander Demchenko (Phoenix), Derdiedasx, Itachi8539

---

## 1. Project Overview

The University Management System is a console-based Java application that simulates core operations of a university: user management, course registration, grading, research activity, news, tech support, and multilingual interface (EN / RU / KZ).

The system is built entirely in plain Java 17 without any external frameworks or build tools. All data is persisted using Java serialization.

---

## 2. How to Run

### Requirements
- Java 17+

### Compile
```bash
# PowerShell
Get-ChildItem -Recurse -Filter "*.java" | Select-Object -ExpandProperty FullName | Out-File sources.txt -Encoding utf8
javac -encoding UTF-8 -d out "@sources.txt"
```

### Run
```bash
chcp 65001
java "-Dfile.encoding=UTF-8" "-Dstdout.encoding=UTF-8" "-Dstderr.encoding=UTF-8" -cp out demo.Main
```

### Default Credentials

| Role | Username | Password |
|------|----------|----------|
| Admin | admin | admin123 |
| Teacher (Prof) | almas | pass123 |
| Teacher | sanzhar | pass456 |
| Student | aidar | student1 |
| Student | marat | student2 |
| GraduateStudent | dana | grad1 |
| Manager | bolat | mgr123 |

---

## 3. Package Structure

```
OOP-unniversity-system-project/
├── users/       — User hierarchy, Database (Singleton)
├── course/      — Course, Lesson, Schedule, Room, Attendance
├── mark/        — Mark, AttestationType
├── research/    — Researcher interface, ResearchPaper, Journal (Observer)
├── other/       — Messages (Decorator), News, Requests, Startup, LanguageManager
├── exceptions/  — 5 custom exceptions
└── demo/        — Main, role-based menus, Factory Method creators
```

---

## 4. Class Hierarchy

### 4.1 User Hierarchy

```
User (abstract base)
├── Employee
│   ├── Teacher
│   │   └── ResearchTeacher  implements Researcher
│   ├── Manager
│   ├── Admin
│   └── TechSupportSpecialist
└── Student
    └── GraduateStudent  implements Researcher
```

**`User`** — base class for all system participants.

Fields: `fullName`, `username`, `password`, `language`, `isLogged`  
Key methods: `login(username, password)`, `changePassword()`, `createRequest()`, `update()` (Observer), `setLanguage()`

**`Employee extends User`** — adds salary, message sending.  
Fields: `salary`, `messages`  
Methods: `sendMessage()`, `getMessages()`

**`Teacher extends Employee`**  
Fields: `degree` (DegreeTeacher), `faculty` (FacultyType), `courses`, `rating`  
Methods: `putMark(course, student, point, type)`, `generateReport(course)`, `viewStudents()`, `viewCourses()`

**`ResearchTeacher extends Teacher implements Researcher`** — professors with research activity. All PROFESSOR-level teachers are automatically Researchers.

**`Manager extends Employee`**  
Fields: `managerType` (OR/Dean)  
Methods: `addCourse()`, `removeCourse()`, `addNews()`, `assignCoursesToTeachers()`, `viewStudentsByGPA()`, `generateReport()`

**`Admin extends Employee`**  
Methods: `addUser()`, `removeUser()`, `viewLogs()`

**`TechSupportSpecialist extends Employee`**  
Methods: `viewNewRequests()`, `acceptRequest()`, `rejectRequest()`, `markAsDone()`

**`Student extends User`**  
Fields: `id`, `studyYear`, `degree` (DegreeStudent), `faculty`, `speciality`, `marks` (HashMap\<Course, Mark\>)  
Methods: `registerCourse()` — checks credit limit (21) and fail count (3), `dropCourse()`, `viewMarks()`, `getGpa()`, `rateTeachers()`

**`GraduateStudent extends Student implements Researcher`**  
Fields: `researchSupervisor`, `diplomaProject`, `researchPapers`, `researchProjects`  
Methods: `setResearchSupervisor()` — validates h-index ≥ 3, `setDiplomaProject()`, `calculateHIndex()`

---

### 4.2 Database (Singleton)

```java
public class Database {
    private static Database instance = new Database(BASEPATH);

    public static Vector<User>    users;
    public static Vector<Student> students;
    public static Vector<Teacher> teachers;
    public static Vector<Course>  courses;
    public static Vector<News>    news;
    // ... other collections

    public static void save() { /* serializes all collections */ }
    public static void load() { /* deserializes all collections */ }
    public static void log(String entry) { ... }
    public static List<User> searchUsers(String regex) { ... }
    public static Researcher getTopCitedResearcher() { ... }
}
```

Singleton pattern ensures a single shared data store. All collections are static and accessible globally. Data is persisted to `data/` folder on logout.

---

## 5. Interfaces

### 5.1 `Researcher` (research package)

```java
public interface Researcher {
    List<ResearchPaper> getResearchPapers();
    List<ResearchProject> getResearchProjects();

    default void addResearchPaper(ResearchPaper paper) {
        // validates citations >= 0
        // adds paper to list
        // auto-generates News with topic RESEARCH
    }

    default void printPapers(Comparator<ResearchPaper> c) {
        // sorts and prints papers using given comparator
    }

    default int calculateHIndex() {
        // sorts citations descending
        // counts i where citations[i] >= i+1
    }
}
```

Implemented by: `GraduateStudent`, `ResearchTeacher`

### 5.2 `IMessage` (other package)

```java
public interface IMessage {
    String getSubject();
    String getText();
    User getSender();
    User getReceiver();
    String getDate();
    String getFormattedContent();
}
```

Used as the base for the Decorator pattern chain.

### 5.3 `Observer` / `Subject` (research package)

```java
public interface Observer {
    void update(String message);
}

public interface Subject {
    void subscribe(Observer o);
    void unsubscribe(Observer o);
    void notifyObservers(String message);
}
```

`User implements Observer` — receives notifications from journals.  
`Journal implements Subject` — notifies subscribers when a paper is published.

---

## 6. Design Patterns

### 6.1 Singleton — `Database`

Only one instance of the Database class is created throughout the entire program lifetime.

```java
private static Database instance = new Database(BASEPATH);

public static Database getInstance() {
    return instance;
}
```

Ensures all parts of the system read and write to the same data store.

---

### 6.2 Observer — `Journal` / `User`

When a new paper is published in a Journal, all subscribed users receive a notification.

```java
// Journal.java (Subject)
public void publishPaper(ResearchPaper paper) {
    papers.add(paper);
    notifyObservers("New paper published: " + paper.getTitle());
}

public void notifyObservers(String message) {
    for (Observer o : subscribers) {
        o.update(message);
    }
}

// User.java (Observer)
public void update(String message) {
    System.out.println("[Notification] " + fullName + ": " + message);
}
```

Users subscribe via `user.subscribeToJournal(journal)`.

---

### 6.3 Factory Method — `UserCreator`

Abstracts the creation of different user types.

```java
// Abstract creator
public abstract class UserCreator {
    public abstract User createUser(String fullName, String username,
                                    String password, Object... params);
}

// Concrete creators
public class StudentCreator extends UserCreator { ... }
public class TeacherCreator extends UserCreator { ... }
public class AdminCreator  extends UserCreator { ... }
public class ManagerCreator extends UserCreator { ... }
```

Allows adding new user types without changing existing creation logic.

---

### 6.4 Decorator — `IMessage` / `MessageDecorator`

Dynamically adds behavior (urgency markers, encryption) to messages.

```java
// Base interface
public interface IMessage { String getFormattedContent(); ... }

// Base message
public class Message implements IMessage { ... }

// Abstract decorator
public abstract class MessageDecorator implements IMessage {
    protected IMessage wrapped;
    public MessageDecorator(IMessage m) { this.wrapped = m; }
}

// Concrete decorators
public class UrgentMessageDecorator extends MessageDecorator {
    public String getFormattedContent() {
        return "[URGENT] " + wrapped.getFormattedContent();
    }
}

public class EncryptedMessageDecorator extends MessageDecorator {
    public String getFormattedContent() {
        return "[ENCRYPTED] " + Base64-like wrap of wrapped.getFormattedContent();
    }
}
```

Usage: `new UrgentMessageDecorator(new EncryptedMessageDecorator(new Message(...)))`

---

## 7. Custom Exceptions

| Exception | When thrown |
|-----------|-------------|
| `CreditLimitExceededException` | Student tries to register a course that would exceed 21 credits |
| `MaxFailException` | Student tries to register a course they have failed 3 times already |
| `NotResearcherException` | Non-Researcher user tries to join a ResearchProject |
| `InvalidSupervisorException` | Supervisor's h-index is below 3 |
| `LowHIndexException` | h-index is insufficient for a required operation |

```java
// Example: CreditLimitExceededException
public boolean registerCourse(Course course) throws CreditLimitExceededException, MaxFailException {
    if (getTotalCredit() + course.getCredit() > MAX_CREDITS)
        throw new CreditLimitExceededException(
            "Cannot register: would exceed " + MAX_CREDITS + " credit limit.");
    // ...
}
```

---

## 8. Key Features

### 8.1 Mark System

```
Mark = firstAttestation (max 30) + secondAttestation (max 30) + examMark (max 40) = 100
```

Grade scale:
- 90–100 → A
- 80–89  → B+
- 70–79  → B
- 60–69  → C+
- 50–59  → C
- 0–49   → F

### 8.2 h-index Calculation

```java
default int calculateHIndex() {
    List<Integer> citations = /* get all citation counts */;
    Collections.sort(citations, Collections.reverseOrder());
    int h = 0;
    for (int i = 0; i < citations.size(); i++) {
        if (citations.get(i) >= i + 1) h = i + 1;
        else break;
    }
    return h;
}
```

### 8.3 Citation Formats

`ResearchPaper.getCitation(Format)` supports:

- **PLAIN_TEXT**: `Author, "Title", Journal, vol. X, no. Y, pp. Z, YEAR, doi: DOI.`
- **BibTeX**: Standard `@ARTICLE{key, author=..., journal=..., ...}` format

### 8.4 Serialization

All data is persisted to binary files in `data/` using `ObjectOutputStream` / `ObjectInputStream`. Called on logout for each role.

```java
public static void save() {
    serializeUser(); serializeStudent(); serializeTeacher();
    serializeCourse(); serializeMark(); serializeNews();
    // ... all collections
    saveCredentials(); // human-readable credentials.txt
}
```

### 8.5 Multilingual Interface (EN / RU / KZ)

Language is selected at login and stored per user. All UI strings are fetched via:

```java
LanguageManager.getTranslation(key, user.getLanguage())
```

The `LanguageManager` holds a static map of 80+ translation keys for all three languages.

### 8.6 RegEx Search

Admin can search users, courses, and research papers by regular expression:

```java
public static List<User> searchUsers(String regex) {
    return users.stream()
        .filter(u -> u.getFullName().matches(".*" + regex + ".*")
                  || u.getUsername().matches(".*" + regex + ".*"))
        .collect(Collectors.toList());
}
```

### 8.7 Comparators for ResearchPaper

```java
PaperByDate      // implements Comparator<ResearchPaper> — by publication date
PaperByCitations // by citations (descending)
PaperByPages     // by number of pages (descending)
```

Used with `researcher.printPapers(new PaperByCitations())`.

---

## 9. Enumerations

| Enum | Values |
|------|--------|
| `DegreeStudent` | BACHELOR, MASTER, PHD |
| `DegreeTeacher` | TUTOR, LECTURER, SENIOR_LECTURER, ASSOCIATE_PROFESSOR, PROFESSOR |
| `FacultyType` | FIT, BS, CCE, FEOG, FGE, FGGE, ISE, KMA, SMS |
| `Period` | FALL, SPRING, SUMMER |
| `AttestationType` | FIRST, SECOND, EXAM |
| `ManagerType` | OR, Dean |
| `CourseType` | MAJOR, MINOR, FREE_ELECTIVE |
| `LessonType` | LECTURE, PRACTICE, LAB |
| `Language` | EN, RU, KZ |
| `UrgencyLevel` | LOW, MEDIUM, HIGH |
| `RequestStatus` | NEW, VIEWED, ACCEPTED, REJECTED, DONE |
| `Format` | PLAIN_TEXT, BIBTEX |
| `NewsTopic` | RESEARCH, ACADEMIC, GENERAL |

---

## 10. Bonus Features

| Feature | Implementation |
|---------|---------------|
| Schedule & Rooms | `Schedule`, `Lesson`, `Room`, `Day`, `LessonType` |
| Attendance | `Attendance` class tracking per-student per-lesson presence |
| Startups | `Startup` class created by GraduateStudents |
| Recommendation Letters | `RecommendationLetter` written by Teachers for Students |
| RegEx Search | `Database.searchUsers/Courses/ResearchPapers(regex)` |
| Multilingual | EN / RU / KZ with 80+ translation keys |
| Credentials export | `data/credentials.txt` generated on every save |

---

## 11. Problems Encountered & Solutions

### Problem 1 — Multiple BufferedReaders on System.in
**Issue:** `Main.java` and each Demo class created their own `BufferedReader` wrapping `System.in`. When input was piped, the first reader buffered all bytes, leaving the second reader with nothing.

**Solution:** Created a single `BufferedReader br` in `Main.java` and passed it as a parameter to all `Demo.run(user, br)` methods.

---

### Problem 2 — UTF-8 Encoding on Windows Console
**Issue:** Cyrillic characters appeared as `╨Т╤Л╨▒╨╡╤А╨╕╤В╨╡` in the terminal. Initially attempted to fix with `System.setOut(new PrintStream(System.out, true, UTF_8))` which made things worse.

**Solution:** Removed the `System.setOut` wrapper entirely. Used only JVM flags `-Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8` in `launch.json`. Also made the initial language-selection menu ASCII-only (shown before language is chosen).

---

### Problem 3 — Demo menus with text string input
**Issue:** `ManagerDemo` used text sub-commands like `"add course"`, `"by gpa"` — very fragile and user-unfriendly.

**Solution:** Replaced all text-based sub-menus with numbered lists (1/2/3 choices).

---

### Problem 4 — Course/Student selection by typed name
**Issue:** `TeacherDemo` and `StudentDemo` required the user to type exact names (e.g. `"Dr. Almas Bekov"`), which crashed on any typo.

**Solution:** Replaced all name-input prompts with numbered lists populated from `Database.courses`, `Database.students`, `Database.teachers`.

---

### Problem 5 — IDE false "cannot be resolved" errors
**Issue:** After creating new files (`Startup.java`, `RecommendationLetter.java`), the Java Language Server showed red errors on imports despite successful compilation.

**Solution:** Updated `.vscode/settings.json` with `java.project.sourcePaths` and ran "Java: Clean Java Language Server Workspace". Confirmed true build status by running `javac` directly (0 errors).

---

## 12. Team Contributions

| Member | Responsibilities |
|--------|-----------------|
| **Alexander (Phoenix)** | `Researcher` interface, `ResearchPaper`, `ResearchProject`, `DiplomaProject`, h-index algorithm, citation formats (Plain Text / BibTeX), comparators, `GraduateStudent`, all custom exceptions, Decorator pattern (`IMessage`, decorators), Factory Method pattern (`UserCreator`), `Database` search methods, `Startup`, `RecommendationLetter` |
| **Derdiedasx** | `News`, `Comment`, `NewsTopic`, Observer pattern (`Journal`, `Subject`, `Observer`), `TechSupportSpecialist`, `Request`, `RequestStatus`, `UrgencyLevel`, `Message`, `Complaint`, `OfficialMessage`, `Language`, `LanguageManager` |
| **Itachi8539** | `Transcript`, `StudentOrganization`, `CourseType`, `ResearchTeacher`, `Teacher.generateReport()`, `Manager.generateReport()`, `Schedule`, `Room`, `Lesson`, `Attendance`, `Database.logs`, all Demo menus (`StudentDemo`, `TeacherDemo`, `ManagerDemo`, `AdminDemo`, `ResearcherDemo`, `TechSupportDemo`, `GraduateStudentDemo`), `Main.java` |

---

## 13. What Works / What Does Not Work

### ✅ Works
- Full user authentication with language selection (EN/RU/KZ)
- All role-based menus: Student, Teacher, Manager, Admin, GraduateStudent, TechSupport
- Course registration with credit limit (21) and fail count (3) enforcement
- Mark system: first + second attestation + exam → GPA calculation
- Research system: papers, h-index, projects, diploma project
- Citation generation: Plain Text and BibTeX formats
- Observer: Journal subscriptions and notifications
- Decorator: Urgent and Encrypted message wrappers
- Factory Method: typed user creation
- Singleton: Database shared state
- Java serialization: data persists to `data/` folder
- RegEx search in Admin menu
- Transcript generation
- Recommendation letters (Teacher → Student)
- Startup creation by GraduateStudents
- News auto-generation on paper publication
- Multilingual UI: all menus translated to EN/RU/KZ

### ⚠️ Limitations
- No graphical UI — console only
- TechSupport demo requires manually typed request index (no list shown)
- Data resets on each fresh run of `Main.java` (by design — test data is re-created)
- Schedule and Room features created but not exposed in demo menus
